package com.example.sqlite_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper=new DBHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ContentValues values=new ContentValues();

        values.put("sid","2");
        values.put("sname","Annie");
        values.put("branch","CSE");



        long row=db.insert("student",null,values);
        System.out.println(row+"Data Inserted");

        SQLiteDatabase db1=dbHelper.getReadableDatabase();
        String columns[]={"sid","sname","branch"};
        Cursor c=db1.query("student",columns,null,null,null,null,null);
        System.out.println("SID\tSNAME\tBRANCH" );
        if (c.moveToFirst()) {
            do {
                //System.out.println(c.getColumnName(0));
                System.out.println(c.getString(0)+"\t" + c.getString(1)+"\t" + c.getString(2));
            }while(c.moveToNext());
        }

    }

}


