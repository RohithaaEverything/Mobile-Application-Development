package com.example.activitylifecycle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this,"OnStart",Toast.LENGTH_LONG).show();
        Log.d("TagName","OnStart Method Invoked");
        System.out.println("On Start Method .......... Console");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this,"OnResume",Toast.LENGTH_SHORT).show();
        Log.d("TagName1","OnResume Method Invoked");
        System.out.println("On Resume Method .......... Console");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this,"OnPause",Toast.LENGTH_SHORT).show();
        Log.d("TagName2","OnPause Method Invoked");
        System.out.println("On Pause Method .......... Console");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(this,"OnRestart",Toast.LENGTH_SHORT).show();
        Log.d("TagName4","OnRestart Method Invoked");
        System.out.println("On Restart Method .......... Console");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this,"OnStop",Toast.LENGTH_SHORT).show();
        Log.d("TagName5","OnStop Method Invoked");
        System.out.println("On Stop Method .......... Console");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this,"OnDestroy",Toast.LENGTH_SHORT).show();
        Log.d("TagName6","OnDestroy Method Invoked");
        System.out.println("On Destroy Method .......... Console");
    }
}
