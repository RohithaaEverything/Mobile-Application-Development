package com.example.sqlite_demo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "amar.db";
    private static final String DB_PATH_SUFFIX = "/database/";
    static Context ctx;
    private final Context context;

    public DBHelper(@Nullable Context context) {
        super(context, "university.db", null, 1);
        this.context=context;

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table student(sid text,sname text,branch text)");
    }
    public void getDetails() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> contList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM student", null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                System.out.println(cursor.getInt(0));

            }
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE if exists studnet");
        sqLiteDatabase.close();
    }
}