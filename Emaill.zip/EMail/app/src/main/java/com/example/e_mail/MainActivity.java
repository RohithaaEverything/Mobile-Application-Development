package com.example.e_mail;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button b;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b =findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent email=new Intent(Intent.ACTION_SEND);
                email.setType("message/rfc822");
                email.putExtra(Intent.EXTRA_EMAIL,new String[]{"kabshaansariyashaik1806@gmail.com"});
                email.putExtra(Intent.EXTRA_SUBJECT,"Welcome to email compose");
                email.putExtra(Intent.EXTRA_TEXT,"Hill guest ");
                startActivity(Intent.createChooser(email,"choose mail app"));

            }
        });
    }
}


