package com.example.orientation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.OrientationEventListener;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView orientationText;
    private OrientationEventListener orientationEventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        orientationText = findViewById(R.id.orientation_text);

        // Initialize the orientation event listener
        orientationEventListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int orientation) {
                updateOrientationText(orientation);
            }
        };

        // Start listening for orientation changes
        orientationEventListener.enable();
    }

    private void updateOrientationText(int orientation) {
        String orientationString = getOrientationString(orientation);
        orientationText.setText("Orientation: " + orientationString);
    }

    private String getOrientationString(int orientation) {
        if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) {
            return "Unknown";
        } else if (orientation >= 315 || orientation < 45) {
            return "Portrait";
        } else if (orientation >= 45 && orientation < 135) {
            return "Landscape (Clockwise)";
        } else if (orientation >= 135 && orientation < 225) {
            return "Portrait (Upside Down)";
        } else {
            return "Landscape (Counterclockwise)";
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Stop listening for orientation changes
        orientationEventListener.disable();
    }
}