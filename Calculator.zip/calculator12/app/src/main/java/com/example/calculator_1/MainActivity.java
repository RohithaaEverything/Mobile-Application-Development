package com.example.calculator_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView input_tv,result_tv ;
    Button button_sin,button_cos,button_tan,button_log,button_ln;
    Button button_fact,button_sq,button_root,button_frac,button_pi;
    Button button_AC,openbracket,closedbracket,button_div;
    Button button1,button2,button3,button_mul;
    Button button4,button5,button6,button_sub;
    Button button7,button8,button9,button_add;
    Button button_C,button0,button_dot,button_equal;

    String pi = "3.14159265";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5= findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        button0 = findViewById(R.id.button0);
        button_pi=findViewById(R.id.button_pi);
        button_dot = findViewById(R.id.button_dot);
        button_equal = findViewById(R.id.button_equal);
        button_add = findViewById(R.id.button_add);
        button_sub = findViewById(R.id.button_sub);
        button_mul = findViewById(R.id.button_mul);
        button_div = findViewById(R.id.button_div);
        button_frac = findViewById(R.id.button_frac);
        button_root = findViewById(R.id.button_root);
        button_sq = findViewById(R.id.button_sq);
        button_fact = findViewById(R.id.button_fact);
        button_ln = findViewById(R.id.button_ln);
        button_log = findViewById(R.id.button_log);
        button_tan = findViewById(R.id.button_tan);
        button_sin = findViewById(R.id.button_sin);
        button_cos = findViewById(R.id.button_cos);
        openbracket = findViewById(R.id.openbracket);
        closedbracket = findViewById(R.id.closedbracket);
        button_C = findViewById(R.id.button_C);
        button_AC = findViewById(R.id.button_AC);

        result_tv = findViewById(R.id.result_tv);
        input_tv = findViewById(R.id.input_tv);

        //onclick listeners
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"1");
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"9");
            }
        });
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"0");
            }
        });
        button_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+".");
            }
        });
        button_AC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result_tv.setText("");
                input_tv.setText("");
            }
        });
        button_C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val = input_tv.getText().toString();
                val = val.substring(0, val.length() - 1);
                input_tv.setText(val);
            }
        });
        button_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"+");
            }
        });
        button_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"-");
            }
        });
        button_mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"*");
            }
        });
        button_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"/");
            }
        });
        button_root.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"√");

            }
        });
        openbracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"(");
            }
        });
        closedbracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+")");
            }
        });
        button_pi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(button_pi.getText());
                result_tv.setText(result_tv.getText()+pi);
            }
        });
        button_sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"sin");
            }
        });
        button_cos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"cos");
            }
        });
        button_tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"tan");
            }
        });
        button_frac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText("1/"+input_tv.getText());
            }
        });
        button_fact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"!");
            }
        });
        button_sq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"^");
            }
        });
        button_ln.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"ln");
            }
        });
        button_log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input_tv.setText(input_tv.getText()+"log");
            }
        });
        button_equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val = input_tv.getText().toString();

                double result = eval(val);
                result_tv.setText(String.valueOf(result));

            }
        });

    }

    //factorial function
    static double factorial(double n) {
        if (n < 0)
            throw new RuntimeException("Factorial is not defined for negative numbers");
        return (n == 1 || n == 0) ? 1 : n * factorial(n - 1);
    }


    //eval function
    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char)ch);
                return x;
            }


            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if      (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if      (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') { // functions and factorial
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    if (func.equals("√")) {
                        nextChar(); 
                        x = parseFactor();
                        if (x < 0)
                            throw new RuntimeException("Square root of a negative number is undefined");
                        x = Math.sqrt(x);
                    } else if (func.equals("sin")) {
                        x = parseFactor();
                        x = Math.sin(Math.toRadians(x));
                    } else if (func.equals("cos")) {
                        x = parseFactor();
                        x = Math.cos(Math.toRadians(x));
                    } else if (func.equals("tan")) {
                        x = parseFactor();
                        x = Math.tan(Math.toRadians(x));
                    } else if (func.equals("log")) {
                        x = parseFactor();
                        x = Math.log10(x);
                    } else if (func.equals("ln")) {
                        x = parseFactor();
                        x = Math.log(x);
                    } else if (eat('!')) {
                        x = parseFactor();
                        if (x != (int) x || x < 0)
                            throw new RuntimeException("Factorial is defined only for non-negative integers");
                        x = factorial((int) x);
                    } else {
                        throw new RuntimeException("Unknown function: " + func);
                    }
                } else {
                    throw new RuntimeException("Unexpected: " + (char)ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }


        }.parse();

    }

}